"""Codecs used for encoding or decoding data should live here


"""
