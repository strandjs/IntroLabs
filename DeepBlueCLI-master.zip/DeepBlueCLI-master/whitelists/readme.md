Placeholder for whitelists directory
